Sky/Cloud boxes created by Zachery "skiingpenguins" Slocum
(freezurbern@gmail.com)
http://www.freezurbern.com
If you do use them, feel free to send me an email. I'd enjoy playing whatever game you put them in.

Originally created for the first person shooter engine "Cube 2: Sauerbraten"

This readme includes the attribution required by the license, hence you are encouraged copy it along with the content (although attribution could be provided by other reasonable means).
Content released under the Creative Commons Attribution-ShareAlike? 3.0 Unported License.
http://creativecommons.org/licenses/by-sa/3.0/

This license applies to the following:
gloom
